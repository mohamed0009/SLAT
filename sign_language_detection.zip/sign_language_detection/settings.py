INSTALLED_APPS = [
    # ... existing apps ...
    'detection',
] 